<?php
    $con = new mysqli("localhost", "root", "", "srkrcollege");
?>